from setuptools import setup
setup(name="hello-world")
